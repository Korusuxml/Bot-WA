const listsewa_ = ` Price Sewa 𝐅𝐮𝐫𝐢𝐧𝐚 𝐁𝐨𝐭 𝐀𝐢

🎆 3 Hari   = 4K
🎆 7 Hari   = 10K
🎆 3 Minggu = 21K
🎆 1 Bulan  = 30K

Untuk Melanjutkan Sewa Silahkan Hubungi Owner https://wa.me/6281277811884?text=Halo,%20saya%20ingin%20sewa%20bot%20furina%20min

Jika Bot Belum Bergabung ke Grub Sewa Silakan ketik *.sewa*`;

module.exports = {
    listsewa_
};
